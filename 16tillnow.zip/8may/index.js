const express = require("express");
const path = require("path");
const cookieParser = require('cookie-parser');
const { connectToMongoDB } = require('./connect');
const { restrictedToLoggedinUserOnly,checkAuth } = require("./middlewares/auth.js");
const URL = require("./models/url.js");

const urlRoute = require("./routes/url.js");
const staticRouter = require("./routes/staticRouter");
const userRoute = require('./routes/user.js');

const app = express();
const PORT = 8001;

connectToMongoDB('mongodb://localhost:27017/short-url').then(()=>console.log("MongoDB connnected"));

app.set("view engine" , "ejs");
app.set("views", path.resolve("./views"));


// let's make a static router(frontend pages)



// app.get("/test",async(req,res)=>{
//     const allUrls = await URL.find({});
//     return res.end(`
//         <html>
//         <head></head>
//         <body>
//         <ol>
//         ${allUrls.map(url => `<li>${url.shortId} - ${url.redirectURL} - ${url.visitHistory.length}</li>`).join("")}
//         </ol>
//         </body>
//         </html>`);
// });
// this was for server side rendering, we will use ejs(embedded javascript templates)


app.use(express.json());
app.use(express.urlencoded({ extended: false}));
app.use(cookieParser());


app.use("/url",restrictedToLoggedinUserOnly,urlRoute);
// inline middleware 
app.use("/user",userRoute);
app.use("/",checkAuth,staticRouter);


app.get('/url/:shortId', async (req, res) => {
    const shortId = req.params.shortId;
    console.log("Looking for:", shortId);

    const entry = await URL.findOneAndUpdate(
        { shortId },
        {
            $push: {
                visitHistory: {
                    timestamp: Date.now()
                }
            }
        }
    );

    if (!entry) {
        return res.status(404).json({ error: "Short URL not found" });
    }

    // Ensure redirection works even if protocol is missing
    const redirectURL = entry.redirectURL.startsWith("http")
        ? entry.redirectURL
        : `https://${entry.redirectURL}`;

    return res.redirect(redirectURL);
});




app.listen(PORT,()=> console.log(`server started at PORT ${PORT}`));




// install ejs
// set view engine as ejs in index.js
// set the views folder path
// by res.render data will be returned by function set in staticRouter.js


// -----
// npm init in terminal



// authentication-
// statefull - maintains state or data on server side
// stateless - no such ...

// uid can be transfered by cookies,response or headers 
// client->auth middleware->endpoint route

