const { getUser } = require("../service/auth");

// stateless---------------
async function restrictedToLoggedinUserOnly(req,res,next){
    const userUid = req.cookies?.uid;
    if(!userUid) return res.redirect("/login");
    const user = getUser(userUid);

    if(!user) return res.redirect("/login");

    req.user = user;
    next();
}



// async function checkAuth(req,res,next){
//     const userUid = req.cookies?.uid;
//     const user = getUser(userUid);

//     req.user = user;
//     next();
// }



//-------------------------------------

async function checkAuth(req,res,next){
    const userUid = req.headers['authorization'];
    const token = userUid?.split('Bearer ')[1]?.trim();
    if (!token) return next();

    const user = getUser(token);

    req.user = user;
    next();
}

// now we got authorization named header, frontend is responsible for how token is sent

// thus 2 ways--
// 1 cookie-automatic type but only for browser 
// 2  headers - token sent in form of token, it comes back as header, in it built in bearer.Bearer means token based authentication


// authentication means to login by checking it is registered
// authorisation means to check whether allowed or not


module.exports={
    restrictedToLoggedinUserOnly,
    checkAuth,
}