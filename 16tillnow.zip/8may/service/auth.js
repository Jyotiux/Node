// sessionId generated in controllers/user.js, to save it with other details of user, this auth.js is made
// npm install uuid

// login process is completed, we are getting uid on applicaiton/cookies in inspect

// ---------statefull authentication
// const sessionIdToUserMap = new Map();
// // hashmap

// function setUser(id,user){
//     sessionIdToUserMap.set(id,user);
// }

// function getUser(id){
//     return sessionIdToUserMap.get(id);
// }

// module.exports = {
//     setUser,
//     getUser,
// };


// stateless authentication-------

const jwt = require("jsonwebtoken");
const secret = "Jyoti$";

function setUser(user){
    return jwt.sign({
        name:user.name,
        email:user.email,
    },secret);
}

function getUser(token){
    if(!token) return null;
    return jwt.verify(token,secret);
}

module.exports = {
    setUser,
    getUser,
};



// in statefull data stored was removed on refreshing(used in banking websites, they make sessions)
// social media websites create tokens for longer time data storage(stateless auth)
// statefull auth can be continued by storing the details in database but.  1)latency(session created by a user on a system , details go to the system having the database, furhtermore verify the details then send back to user)   2)query on every request in database, we would have to pay a lot on read operations. so not good for real world.Bill will get increased.
// jwt tokens are assigned to user and they are signed so can not be alterd by user




// the tokens generated can be sent to user as 1) cookies  2) response
// user token stored in cookie, the browser stores cookieStore(so, on any get, post... request cookies will be sent to user)


// cookies are domain specific
// req with header having the token is sent to the user

// authorization->