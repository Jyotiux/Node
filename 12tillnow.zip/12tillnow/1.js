// console.log("Jyoti");

// 1 export

// const math= require("./math");
// console.log(math.add(2,5));
// console.log(math.sub(5,2));
// -------

// 2 server creation

// const http = require("http");
// const server = http.createServer((req,res)=> {
//     res.writeHead(200,{'Content-Type':'text/plain'});
//     res.end("Hello");

// });
// server.listen(3000,() =>{
//     console.log("Server running on port 3000");
// });
// ---------

// 3 asynchronous 

// const fs=require("fs");
// console.log("1")

// fs.writeFile("test.txt","Hey There", (err)=>{
//     if (err) console.log("Error",err);
//     else console.log("2");
// });
// console.log("3");

// ------------------

// 4 handling routes

// const http = require("http");
// const fs = require("fs");

// const myServer = http.createServer((req,res)=>{
// const log = `${Date.now()}: New Request Received\n`;

// fs.appendFile("log.txt", log, (err)=>{
//     if(err) console.error(err);

//     switch(req.url){
//         case "/":
//             res.end("Home Page");
//             break;
//         case "/about":
//             res.end("I am a developer");
//             break;
//         default:
//             res.end("Not Found");
//     }
// });

// });

// myServer.listen(8000,()=>{
//     console.log("Server running on port 8000");
// });

// --------

// 5 url

// const http=require("http");
// const fs = require("fs");
// const url = require("url");

// const myServer = http.createServer((req,res)=>{
//     const log = `${Date.now()}: New Request Received\n`;

//     const myUrl = url.parse(req.url, true);
//     console.log(myUrl);

//     fs.appendFile("log.txt", log,(err) =>{
//         if(err) console.error(err);

//         switch(myUrl.pathname){
//             case "/":
//                 res.end("Home Page");
//                 break;
//             case "/about":
//                 const username = myUrl.query.myname;
//                 res.end(`Hello, ${username}`);
//                 break;

//             case "/search":
//                 const searchQuery = myUrl.query.search_query;
//                 res.end("Results for: " + searchQuery);
//                 break;

//             default:
//                 res.end("Not Found");
//         }
//     });
// });

// myServer.listen(8000, ()=>{
//     console.log("Server running on port 8000");
// })

// // http://localhost:8000/about?myname=Jyoti

// -----------
// 6. http methods

// const http = require("http");
// const fs = require("fs");
// const url = require("url");

// const myServer = http.createServer((req, res) => {
//     const log = `${Date.now()}: ${req.method} New Request Received\n`;
//     const myUrl = url.parse(req.url, true);

//     // Append log asynchronously (non-blocking)
//     fs.appendFile("log.txt", log, (err) => {
//         if (err) console.error(err);

//         switch (myUrl.pathname) {
//             case "/":
//                 res.end("Home Page");
//                 break;

//             case "/about":
//                 const username = myUrl.query.myname;
//                 res.end(`Hi, ${username}`);
//                 break;

//             case "/search":
//                 const search = myUrl.query.search_query;
//                 res.end("Results are: " + search);
//                 break;

//             case "/signup":
//                 if (req.method === "GET") {
//                     res.end("This is a signup form");
//                 } else if (req.method === "POST") {
//                     res.end("Signup successful");
//                 }
//                 break;

//             default:
//                 res.end("Not Found");
//         }
//     });
// });

// myServer.listen(8000, () => {
//     console.log("Server started on port 8000");
// });

// ------------

// 7 express

// const express = require("express");
// const app = express();

// app.get("/",(req,res)=>{
//     res.send("Home Page");
// })

// app.listen(8000,()=> console.log("Server started at 8000"));


//-----------------

// GET /users -HTML Document Reader
// GET /api/users - List all users json
// GET /api/users/1 - Get the user with ID 1

// Dynamic Path parameters
// GET /api/users/:id
// :id -> Variable | Dynamic

// POST /api/users - Create new user
// PATCH /api/users/1 - Edit the users with ID 1
// DELETE /api/users/1 - Delete the users with ID 1


// const express = require('express');
// const users= require('./MOCK_DATA.json');
// const path = require("path");
// const fs=require('fs');
// const mongoose = require("mongoose");
// const { type } = require('os');
// const app =express();
// const PORT = 8000;

// mongoose
//     .connect("mongodb://localhost:27017/youtubedb")
//     .then(() => console.log("Mongoose Connected"))
//     .catch((err) => console.log("Mongo Error",err));  
    
// // Schema
// const userSchema = new mongoose.Schema({
//     first_name:{
//         type: String,
//         required: true
//     },
//     last_name:{
//         type: String,
//     },
//     email: {
//         type: String,
//         required: true,
//         unique: true,
//     },
//     jobTitle: {
//         type:String,
//     },
//     gender:{
//         type: String,
//     },
// });

// const User = mongoose.model("user",userSchema);

// // middleware plugin
// app.use(express.urlencoded({extended: false}));

// // Middlewares
// app.use((req,res,next)=>{
//     console.log("Hello from middleware 1");
//     // return res.json({msgs:"Hello from middleware 1"});
//     fs.appendFile("log.txt",
//         `${Date.now()}: ${req.method}: ${req.path}\n`,
//         (err,data)=>{
//             next();
//         }
//     );
//    });
   
// // If we keep till console.log then postman gets stuck in get request also

// app.use((req,res,next)=>{
//     console.log("Hello from middleware 2");
//     next();
// })



// // Routes
// app.get("/api/users",(req,res)=>{
//     res.setHeader("X-MyName","Jyoti");
//     // Good practice to add custom header with X.
//     return res.json(users);
// });

// // app.get("/users",(req,res)=>{
// //     const html=`
// //     <ul>
// //     ${users.map((user)=>`<li>${user.first_name}</li>`).join("")}
// //     </ul>
// //     `;
// //     res.send(html);
// // });

// app.get("/api/users/:id",(req,res)=>{
//     const id =Number(req.params.id);
//     const user =users.find((user)=>user.id===id);
//     return res.json(user);
// });

// // app.post("/api/users",(req,res)=>{
// //     //Create new user
// //     return res.json({status:"pending"});
// // });


// app.patch("/api/users/:id", (req, res) => {
//     const id = Number(req.params.id);
//     const body = req.body;

//     // Find index of the user to update
//     const userIndex = users.findIndex((user) => user.id === id);

//     if (userIndex === -1) {
//         return res.status(404).json({ error: "User not found" });
//     }

//     // Update user fields with new data
//     users[userIndex] = { ...users[userIndex], ...body };

//     // Write updated users array to file
//     fs.writeFile(
//         path.join(__dirname, "./MOCK_DATA.json"),
//         JSON.stringify(users, null, 2),
//         (err) => {
//             if (err) {
//                 return res.status(500).json({ error: "Failed to write to file" });
//             }

//             return res.json({
//                 status: "User updated",
//                 user: users[userIndex],
//             });
//         }
//     );
// });


// // app.patch("/api/users/:id",(req,res)=>{
// //     //Edit the user with id
// //     fs.writeFile("./MOCK_DATA.json",JSON.stringify(users),(err, data)=>{
// //         return res.json({status:"pending", user: body});
// //     })
// //     return res.json({status:"pending"});
// // });

// app.delete("/api/users/:id", (req, res) => {
//     const id = Number(req.params.id);

//     // Find index of the user to delete
//     const userIndex = users.findIndex(user => user.id === id);

//     if (userIndex === -1) {
//         return res.status(404).json({ error: "User not found" });
//     }

//     // Remove user from array
//     const deletedUser = users.splice(userIndex, 1);

//     // Write updated users array to file
//     fs.writeFile(
//         path.join(__dirname, "MOCK_DATA.json"),
//         JSON.stringify(users, null, 2),
//         (err) => {
//             if (err) {
//                 return res.status(500).json({ error: "Failed to update file" });
//             }

//             return res.json({
//                 status: "User deleted successfully",
//                 user: deletedUser[0]
//             });
//         }
//     );
// });

// app.get("/api/users/:id",(req,res)=>{
//     const id =Number(req.params.id);
//     const user =users.find((user)=>user.id===id);
//     if(!user)return res.status(404).json({error:'user not found'});
//     return res.json(user);
// });

// app.post("/api/users",async(req,res)=>{
//     const body = req.body;
//     if(
//         !body ||
//         !body.first_name ||
//         !body.last_name ||
//         !body.email ||
//         !body.gender ||
//         !body.job_title
//     ){
//         return res.status(400).json({msg:"All fields are required"});
//     }
//     // users.push({...body, id: users.length+1});
//     // fs.writeFile("./MOCK_DATA.json",JSON.stringify(users),(err, data)=>{
//     //     return res.status(201).json({status:"pending", user: body});
//     // })
//     // console.log("Body",body);
//     // return res.json({ status: "User received", user: body });
//     const result = await User.create({
//         first_name: body.first_name,
//         last_name: body.last_name,
//         email: body.email,
//         gender: body.gender,
//         job_title: body.job_title,
//     });
//     console.log("result",result);
//     return res.status(201).json({msg:"success"});
// });

// // this gives 201 as response status, created

// app.listen(PORT,()=>console.log(`Server started at Port: ${PORT}`));

// // setup postman to check the methods
 
// -------------------
// -------------------------



// // import express,json data,path,fs,create app of express

// const express= require('express');
// const users=require("./MOCK_DATA.json");
// const path=require("path");
// const fs=require("fs");
// // const { default: mongoose } = require('mongoose');
// const app=express();
// const PORT=8000;


// // middleware
// app.use(express.urlencoded({extended:false}));


// // Routes
// app.get("/users",(req,res)=>{
//     const html=`
//     <ul>
//     ${users.map((user)=>`<ul>${user.first_name}</ul>`).join("")}
//     </ul>
//     `;
//     res.send(html);

// })

// app.get("/api/users/:id",(req,res)=>{
//     const id=Number(req.params.id);
//     const user = users.find((user)=>user.id===id);
//     return res.json(user);
// })

// app.post("/api/users",(req,res)=>{
//     // create new use
// })

// // patch
// // delete

// app.listen(PORT,()=>console.log(`Server started at PORT: ${PORT}`));

// ----------------------------


// const express = require('express');
// const users = require('./MOCK_DATA.json');
// const path = require('path');
// const fs = require('fs');
// const mongoose = require('mongoose');
// const app=express();
// const PORT=8000;

// // mongoose
// //     .connect("mongodb://localhost:27017/youtubedb")
// //     .then(() => console.log("Mongoose Connected"))
// //     .catch((err) => console.log("Mongo Error",err));  

// // MongoDB connection
// mongoose.connect('mongodb://localhost:27017/youtubedb', {
//     useNewUrlParser: true,
//     useUnifiedTopology: true
// }).then(() => {
//     console.log('Connected to yourDB database');
// }).catch((err) => {
//     console.log('Error connecting to database', err);
// });

// //Schema
// const userSchema = new mongoose.Schema({
//     first_name:{
//         type: String,
//         required: true
//     },
//     last_name:{
//         type: String,
//     },
//     email: {
//         type: String,
//         required: true,
//         unique: true,
//     },
//     gender:{
//         type: String,
//     },
// })

// const User = mongoose.model("user",userSchema);

// app.use(express.urlencoded({extended: false}));

// app.get("/api/users",(req,res)=>{
//     res.setHeader("X-MyName","Jyoti");
//     return res.json(users);
// });

// app.get("/users",(req,res)=>{
//     const html=`
//     <ul>
//     ${users.map((user)=>`<li>${user.first_name}</li>`).join("")}
//     </ul>
//     `;
//     res.send(html);
// });

// app.get("/api/users/:id",(req,res)=>{
//     const id = Number(req.params.id);
//     const user =users.find((user)=>user.id===id);
//     return res.json(user);
// });

// app
//     .route("/api/users/:id")
//     .get(async (req,res)=>{
//         const user=
//     })
// // post
// // put
// // patch
// // delete

// app.listen(PORT,()=>console.log(`Server started at Port: ${PORT}`));

// // ---------------------------


// MVC
// Model View Controller
// View<-Model<-Controller

// Controller manipulates model, and model updates View


const express = require('express');
const users = require('./MOCK_DATA.json');
const path = require('path');
const app=express();
const PORT=8000;

const { logReqRes } = require("./middleware");
// bydefault index.js will be imported
const { connectMongoDb } = require("./connection.js");
const userRouter=require('./routes/user.js');

connectMongoDb("mongodb://localhost:27017/youtubedb").then(()=> console.log('Mongodb connected'));


app.use(logReqRes("log.txt"));
app.use("/user",userRouter);


app.listen(PORT,()=>console.log(`Server started at Port: ${PORT}`));

// in index.js(this file) flow is decided
// mongodb connect, initialise middlewares,initialise routes

// in connection.js mongodb is connected
// in routes, we take only /user routes
